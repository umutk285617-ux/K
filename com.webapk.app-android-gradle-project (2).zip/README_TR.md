# Sign in - Google Accounts — Android Studio / Gradle Projesi

Bu proje **ProDev Studio** tarafından otomatik olarak yapılandırılmıştır.

## Uygulama Bilgileri
- **Uygulama Adı:** Sign in - Google Accounts
- **Paket Kimliği (applicationId):** `com.webapk.app`
- **Sürüm:** 1.0.0 (Version Code: 1)
- **Ekran Yönü:** portrait
- **İzinler:** INTERNET, ACCESS_NETWORK_STATE
- **Firebase:** google-services.json yapılandırması projeye entegre edilmiştir.

## APK Dosyasını Nasıl Alabilirsiniz?

### 1. Yöntem: GitHub ile Ücretsiz ve Otomatik Bulut Derlemesi (Önerilen)
Bu ZIP dosyası içinde hazır `.github/workflows/build-apk.yml` otomasyonu bulunmaktadır:
1. Bu projeyi **GitHub** üzerinde ücretsiz bir depoya (Repository) yükleyin (veya dosyaları yükleyin).
2. GitHub'daki **Actions** sekmesinde derleme otomatik başlar.
3. 2-3 dakika içinde **Artifacts** bölümünden gerçek imzalanmış `.apk` dosyanızı doğrudan telefonunuza indirebilirsiniz!

### 2. Yöntem: Android Studio ile Bilgisayarınızda Derleyin
1. Bu ZIP arşivini bilgisayarınızda bir klasöre çıkartın.
2. **Android Studio** uygulamasını açın ve **Open** seçeneği ile bu klasörü seçin.
3. Gradle eşitlemesi tamamlandığında üst menüden **Build > Build Bundle(s) / APK(s) > Build APK(s)** seçeneğine tıklayın.

### 3. Yöntem: Komut Satırı (Terminal) ile
```bash
./gradlew assembleDebug
```
Derlenen APK dosyası: `app/build/outputs/apk/debug/app-debug.apk` konumunda hazır olur.
